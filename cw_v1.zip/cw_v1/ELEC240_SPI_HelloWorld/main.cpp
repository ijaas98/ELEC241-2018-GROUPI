#include "mbed.h"

#define DD 25                   //Display Delay us
#define CD 2000                 //Command Delay us

SPI spi(PA_7, PA_6, PA_5);      // Ordered as: mosi, miso, sclk could use forth parameter ssel
                                // However using multi SPI devices within FPGA with a seperate chip select
SPI spi_cmd(PA_7, PA_6, PA_5);  // NB another instance call spi_cmd for 8 bit SPI dataframe see later line 37
                                // For each device NB PA_7 PA_6 PA_5 are D11 D12 D13 respectively
DigitalOut cs(PC_6);            // Chip Select for Basic Outputs to illuminate Onboard FPGA DEO nano LEDs CN7 pin 1
DigitalOut LCD_cs(PB_15);       // Chip Select for the LCD via FPGA CN7 pin 3
DigitalOut ADC_cs(PB_9);        // Chip Select for the ADC via FPGA CN7 pin 4

//Function Prototypes, will just output a string to display, see later
int32_t bar_graph(uint8_t level);   //Display a bar graph on the lcd 2nd line scale 0 to 15
void pulse_bar_graph(void);         //Show a quick Bar up down and clear
int32_t read_adc(void);             //Read ADC and return the 12 Bit value 0 to 4095 NB has a 3V3 refernce voltage (for scaling)
int32_t read_switches(void);        //Read 4 Sliding switches on FPGA (Simulating OPTO-Switches from Motor(s)

int32_t lcd_cls(void);              //LCD Functions here, Clear Screen, Locate and Display String
int32_t lcd_locate(uint8_t line, uint8_t column); //Line Max is 2, Column max is 16
int32_t lcd_display(char* str);     //String str length maximum is 16

//NBB the following line for F429ZI !!!!
DigitalIn DO_NOT_USE(PB_12);    // MAKE PB_12 (D19) an INPUT do NOT make an OUTPUT under any circumstances !!!!! ************* !!!!!!!!!!!
                                // This Pin is connected to the 5VDC from the FPGA card and an INPUT is 5V Tolerant

//Ticker ticktock;
 
int main() {
    cs = 1;                     // Chip must be deselected, Chip Select is active LOW
    LCD_cs = 1;                 // Chip must be deselected, Chip Select is active LOW
    ADC_cs = 1;                 // Chip must be deselected, Chip Select is active LOW
    spi.format(16,0);           // Setup the DATA frame SPI for 16 bit wide word, Clock Polarity 0 and Clock Phase 0 (0)
    spi_cmd.format(8,0);        // Setup the COMMAND SPI as 8 Bit wide word, Clock Polarity 0 and Clock Phase 0 (0)
    spi.frequency(1000000);     // 1MHz clock rate
    spi_cmd.frequency(1000000); // 1MHz clock rate
    
    int adval_d = 0;            //A to D value read back
    float adval_f =0.0f;
    int err = 0;                //error variable used for debugging, trapping etc.,

    char adval[32];
    
// Preload some arrays
//    char hello_world[]="Hello World";
    char splash_screen1[]="Ijaas";
    char splash_screen2[]="Plymouth UNI";
    char DVM[]="Voltage=";
	
// Start up sequences
    lcd_cls();
    lcd_locate(1,1);
    lcd_display(splash_screen1);    //Credit line 1
    lcd_locate(2,2);
    lcd_display(splash_screen2);    //Credit line 2
    wait(2);
    lcd_cls();
    pulse_bar_graph(); //Flashy bargraph clear screen  
    lcd_locate(1,0);
    lcd_display(DVM);   //Type Voltage display
    lcd_locate(1,13);
    lcd_display("V");   //Units display
   
    while(true)                 //Loop forever Knight Rider Display on FPGA
    {
        adval_d = read_adc();
        
        adval_f = 3.3f*((float)adval_d/4095);//Convert 12 bit to a float and scale
        sprintf(adval,"%.3f",adval_f);       //Store in an array string
        lcd_locate(1,8);                     //and display on LCD
        lcd_display(adval);                  //
        
        err = bar_graph(adval_d/255);       // 16*256 =4096 12 bit ADC!
        if (err < 0){printf("Display Overload\r\n");}
        
        read_switches();
        //LED Chaser display KIT lives on!
        for (uint32_t i=1;i<=128;i*=2)
        {
            cs = 0;             //Select the device by seting chip select LOW
            spi_cmd.write(0);
            spi.write(i);
            cs = 1;             //De-Select the device by seting chip select HIGH
            wait_ms(20);
        }
        for (uint32_t i=128;i>=1;i/=2)
        {
            cs = 0;             //Select the device by seting chip select LOW
            spi_cmd.write(0);
            spi.write(i);
            cs = 1;             //De-Select the device by seting chip select HIGH
            wait_ms(20);
        }
    }
}


int lcd_cls(void){
    LCD_cs = 0;spi_cmd.write(0);spi.write(0x0001);LCD_cs = 1;wait_us(CD);    //Clear Screen
    return 0;
}

int lcd_locate(uint8_t line, uint8_t column){
    uint8_t line_addr;
    uint8_t column_addr;
    switch(line){
        case 1: line_addr=0x80; break;
        case 2: line_addr=0xC0; break;
        default: return -1; //return code !=0 is error
        }
    if(column<16){column_addr=column;}
    else{return -1;}
    LCD_cs = 0;
    spi_cmd.write(0);
    spi.write(line_addr+column_addr);
    LCD_cs = 1;
    wait_us(CD); //DDRAM location Second line is 0x00C0 first line starts at 0x0080
    return 0;
}

int lcd_display(char* str){
    
    if (strlen(str)>16){return -1;} //return code !=0 is error
    
    uint8_t command_data=1;
    uint32_t wait_time;
 
    switch(command_data){
        case 0: wait_time=DD; break;
        case 1: wait_time=CD; break;
        default: return -1;
        }

    for (int i=0; i<strlen(str);i++){
        LCD_cs = 0;
        spi_cmd.write(0);
        spi.write((command_data<<8)+str[i]);
        LCD_cs = 1;
        wait_us(wait_time);
    }
    return 0;
}

int bar_graph(uint8_t level){
    if (level>16){return -1;} //return code !=0 is error
    LCD_cs = 0;spi_cmd.write(0);spi.write(0x00C0);LCD_cs = 1;wait_us(CD); //DDRAM location Second line is 0x00C0 first line starts at 0x0080
    for (int i=1; i<=level ;i++)
    {
        if(level>0){LCD_cs = 0;spi_cmd.write(0);spi.write(0x01FF);LCD_cs = 1;wait_us(DD);}   // BLACK SPACE
        else{LCD_cs = 0;spi_cmd.write(0);spi.write(0x0120);LCD_cs = 1;wait_us(DD);}          // WHITE SPACE
    }
    for (int i=level; i<=16 ;i++)
    {
        LCD_cs = 0;spi_cmd.write(0);spi.write(0x0120);LCD_cs = 1;wait_us(DD); // SPACE
    }
    return 0; // return code ==0 is OK
}

int read_adc(void){
    int adval_d;
    float adval_f;
    ADC_cs = 0;
    adval_d = spi.write(0x00);
    ADC_cs =1 ;
    adval_f = 3.3f*((float)adval_d/4095);
    printf("%d %.3fV\r\n",adval_d,adval_f);
    return adval_d;    
}

void pulse_bar_graph(void){
    for (uint8_t i=0;i<16;i++)
    {
        printf("%u\r\n",i);
        bar_graph(i);
        wait_ms(100);
    }
    for (int8_t i=15;i>=0;i--)
    {
        printf("%u\r\n",i);
        bar_graph(i);
        wait_ms(100);
    }
}

int read_switches(void){
    int sw_val;
    cs = 0;
    spi_cmd.write(0);
    sw_val = spi.write(0x00)&0x0F; // Just want lower 4bit nibble
    cs = 1 ;
    if (sw_val&(1<<0)){printf("Switch 0 :");}
    if (sw_val&(1<<1)){printf("Switch 1 :");}
    if (sw_val&(1<<2)){printf("Switch 2 :");}
    if (sw_val&(1<<3)){printf("Switch 3 :");}
    if (sw_val>0){printf("\r\n");}
    return sw_val;    
}
